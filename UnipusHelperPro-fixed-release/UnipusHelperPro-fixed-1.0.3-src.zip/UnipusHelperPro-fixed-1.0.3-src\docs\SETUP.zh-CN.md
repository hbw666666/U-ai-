# 使用说明（中文）

这是 **UnipusHelperPro 1.0.3 的修复版**。原版有两个很实际的问题，本版本已经修掉。

---

## 零、怎么下载最省事

在仓库文件列表里点 **`UnipusHelperPro-fixed-1.0.3.zip`**（约 8.7 MB），
然后点右上角的 **Download raw file** 下载。

解压后会得到一个完整可用的文件夹：

```
UnipusHelperPro-fixed-1.0.3/
  UnipusHelperPro-1.0.3.jar      程序本体（已修复）
  lib/                           16 个第三方依赖（必须保留，不能删）
  run.bat                        启动脚本（英文提示）
  run.zh-CN.bat                  启动脚本（中文提示）
  find-java.ps1                  自动寻找 Java 25+
  unipushelper.properties.template  提交节奏配置模板
  README.md / docs/              说明文档
  src-patch/                     补丁源码（想自己编译才需要）
```

**解压后不要单独把 jar 拿出来**：jar 的 MANIFEST 用相对路径引用 `lib/`，
必须和 `lib/` 放在一起。

另外一个 `UnipusHelperPro-fixed-1.0.3-src.zip`（约 50 KB）只有补丁源码，
给想自己审查或重新编译的人用，不含依赖、不能直接运行。

---

## 一、准备环境

| 项目 | 要求 |
|---|---|
| 系统 | Windows 10 / 11 |
| Java | **JDK / JRE 25 或更高**（本程序的 class 文件是 Java 25 编译的） |
| 依赖 | 压缩包里已经带好 `lib/`，无需另外下载 |

---

## 二、启动

1. 把 `lib/` 目录准备好（从原版发布包里复制过来）。
2. （可选）把 `unipushelper.properties.template` 复制成
   `unipushelper.properties`，按需调整提交节奏。
3. 双击 **`run.bat`**（英文提示）或 **`run.zh-CN.bat`**（中文提示）。
4. 在弹出的窗口里填**你自己的** U校园账号和密码。

本仓库里没有任何预填的账号、密码或 API Key。

启动脚本会自动：

- 检测是否已经在运行，已经在跑就不会再开第二个实例；
- 给本次运行生成独立的日志文件 `logs/latest-<时间戳>.log`；
- 通过 `find-java.ps1` 自动寻找 Java 25+（先看 `JAVA_HOME`，再看注册表，最后看 `PATH`）。

如果想看控制台输出，用 `run.bat --foreground`。

---

## 三、提交节奏（本次修复的重点）

### 问题

原版两次提交之间没有任何间隔，任务做完就立刻提交。实测数据：

```
11:09:59,518  Submitting answers.          <- 本次运行第一次提交
11:10:41,086  Submitting too frequently, wait 2 minutes.
```

也就是说 **41 秒内提交了 12 次（平均 3.4 秒一次）**，服务端直接开始限流，
程序界面显示「提交速度太快」，之后就频繁卡在 2 分钟冷却里，课程跑不完整。

原因有两个：

1. 原版限制「每分钟 5 次」的计数器是 `Learn` 的实例字段，而每个任务都会
   新建一个 `Learn`，计数器每次都从 0 开始 —— 等于没有限制；
2. 提交之间完全没有最小间隔。

### 修复后的默认节奏

| 配置项 | 默认值 | 含义 |
|---|---|---|
| `submit.minIntervalMs` | `20000` | 两次提交之间至少间隔 20 秒 |
| `submit.jitterMs` | `8000` | 再叠加 0~8 秒随机抖动 |
| `submit.maxPerMinute` | `3` | 每分钟最多 3 次提交 |
| `submit.backoffBaseMs` | `120000` | 被限流后首次冷却 2 分钟 |
| `submit.backoffMaxMs` | `900000` | 冷却上限 15 分钟（每次翻倍） |
| `submit.backoffResetMs` | `600000` | 10 分钟没再被限流就重置退避 |

配置文件放在 jar 同级目录，文件名 `unipushelper.properties`；
第一次开始学习任务时程序会自动生成一份带注释的模板。
也可以用 JVM 参数临时覆盖，例如 `-Dsubmit.minIntervalMs=30000`。

**建议**：`minIntervalMs` 不要低于 10000。这个程序的目标是「挂着稳定跑完」，
不是「跑得最快」；调慢只会更稳。

### 被限流了会怎样

- 程序会先按上面的间隔主动等待，界面上会显示等待提示；
- 如果服务端仍然返回限流（600001 / 600002），冷却时间从 2 分钟开始，
  连续触发就翻倍（2 → 4 → 8 → 15 分钟封顶），10 分钟没再触发就恢复；
- 所以即使偶尔被限流，脚本也会自己恢复，不会中断。

---

## 四、日志与隐私

- `logs/` 目录由程序在本地生成，**不要提交到 GitHub**（`.gitignore` 已忽略）。
  日志里包含你的账号 id、课程信息和题目答案，属于隐私内容。
- 登录框的「记住我」用 Java 的 Preferences 保存用户名，存在注册表
  `HKCU\Software\JavaSoft\Prefs\org\unipus` 下，只在你本机。
- 反馈问题时贴日志前请先把账号、姓名等信息打码。

---

## 五、常见问题

| 现象 | 原因 / 处理 |
|---|---|
| `Unable to delete file ... latest.log` | 重复启动了第二个实例。本版本会拦住，并且每次运行用独立日志文件。 |
| 提示 `Java 25 or newer was not found` | 安装 JDK 25+（如 Temurin），或把 `JAVA_HOME` 指向已有的 Java 25+ 目录。 |
| 双击后没反应 | 用 `run.bat --foreground` 启动，这样能看到报错。 |
| 偶尔还是「提交速度太快」 | 把 `submit.minIntervalMs` 调到 30000 再重启。 |
| `run.zh-CN.bat` 中文乱码 | 控制台不是 936 代码页，改用 `run.bat`。 |

---

## 六、说明

- 原程序：**UnipusHelperPro 1.0.3**（原作者发布）。本仓库只提供打了补丁的
  class 文件、补丁源码和启动脚本，其余代码未改动。
- 本版本只做了「提交节奏」和「稳定性」两处修复，不绕过任何登录流程，
  需要你自己的有效账号。
- 请自行承担使用风险，并遵守学校与 U校园 的服务条款。
