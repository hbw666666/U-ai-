UnipusHelperPro 修复版 —— 源码/构建包
======================================

这个包里**没有** lib/ 依赖，也没有完整可运行的 jar；它只包含本次修复涉及的
补丁源码、编译产物、脚本源码和文档，供想自己审查或重新编译的人使用。

想要开箱即用，请下载程序包：UnipusHelperPro-fixed-1.0.3.zip

内容：
  pc-patch/
    org/unipus/Main.java                     修复：单实例锁 + 日志按实例隔离
    org/unipus/unipus/SubmitThrottle.java    新增：全局提交节流器（修复“提交速度太快”）
    org/unipus/unipus/Learn.java             修复：提交路径接入节流器
    classes/                                 上面三个类的编译产物（Java 25）
    log4j2.xml                               修复后的日志配置（移除启动即删除日志的策略）
    MANIFEST.MF                              jar 清单
    run-ascii.bat / run.zh-CN.bat            启动器源码（英文 / 中文）
    find-java.ps1                            探测 Java 25+
  run.bat / run.zh-CN.bat / find-java.ps1    启动器本体
  unipushelper.properties.template           提交节奏配置模板
  README.md / docs/                          说明与改动清单
  make-zip.bat                               重新打包脚本（见下）
  .gitignore                                 仓库忽略规则

重新编译需要 JDK 25+ 以及原版发布包里的 lib/ 依赖，
具体命令见 README.md 的 “Rebuilding after editing the sources”。

重新打包：
  在仓库根目录放好 lib/（从原版发布包复制）后，双击 make-zip.bat
  即可重新生成程序包和源码包。