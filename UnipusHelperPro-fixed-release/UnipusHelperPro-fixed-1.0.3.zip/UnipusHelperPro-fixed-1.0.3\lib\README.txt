lib/ —— 第三方依赖说明
================================

这个目录里的 jar 都不是本项目写的，而是 UnipusHelperPro 运行所必需的
第三方开源库。UnipusHelperPro-1.0.3.jar 的 MANIFEST 里用相对路径
（Class-Path: lib/xxx.jar）引用它们，所以：

    **这个目录必须和 UnipusHelperPro-1.0.3.jar 放在同一层，不能删、不能改名。**

内容与来源
----------

| 文件 | 用途 | 来源 |
|---|---|---|
| okhttp-5.0.0-alpha.14.jar | HTTP 客户端 | square/okhttp (Apache-2.0) |
| okio-jvm-3.9.0.jar | okhttp 的 IO 依赖 | square/okio (Apache-2.0) |
| kotlin-stdlib-1.9.23.jar | okhttp 的 Kotlin 运行时 | JetBrains/kotlin (Apache-2.0) |
| annotations-13.0.jar | okhttp 的注解 | JetBrains (Apache-2.0) |
| gson-2.12.1.jar | JSON 解析 | google/gson (Apache-2.0) |
| error_prone_annotations-2.36.0.jar | gson 的注解 | google/error-prone (Apache-2.0) |
| log4j-api-2.25.2.jar | 日志接口 | apache/logging-log4j2 (Apache-2.0) |
| log4j-core-2.25.2.jar | 日志实现 | apache/logging-log4j2 (Apache-2.0) |
| flatlaf-3.6.1.jar | Swing 界面外观 | JFormDesigner/FlatLaf (Apache-2.0) |
| rsyntaxtextarea-3.6.0.jar | 文本编辑组件 | bobbylight/RSyntaxTextArea (BSD-3) |
| jsoup-1.21.2.jar | HTML 解析 | jhy/jsoup (MIT) |
| jjwt-api-0.12.5.jar | JWT 接口 | jwtk/jjwt (Apache-2.0) |
| jjwt-impl-0.12.5.jar | JWT 实现 | jwtk/jjwt (Apache-2.0) |
| jjwt-gson-0.12.5.jar | JJWT 的 Gson 适配 | jwtk/jjwt (Apache-2.0) |
| junit-4.13.2.jar | 单元测试（运行时不使用） | junit-team/junit4 (EPL-1.0) |
| hamcrest-core-1.3.jar | junit 的依赖 | hamcrest/JavaHamcrest (BSD-3) |

所有这些库都保留各自的原始许可证，请遵循对应项目的许可条款。

这个目录里没有任何个人数据、账号信息或本机路径。
